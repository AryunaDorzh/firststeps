package vierteHausuebung;

import java.util.Scanner;

public class KgV {
	//2. kgV: Lesen Sie zwei Zahlen ein und berechnen Sie das kleinste gemeinsame
	//Vielfache (kgV) dieser Zahlen.


	public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
System.out.print("Bitte geben Sie die erste Zahl ein");
   int zahl1 = scanner.nextInt();
System.out.print("Bitte geben Sie die zweite Zahl ein");
   int zahl2 = scanner.nextInt();
         
        int z1 = zahl1;
        int z2 = zahl2;
         
        while (z1 != z2) {
            if (z1 < z2) {
                z1 += zahl1;
            } else {
                z2+= zahl2;
            }
        }
         
        System.out.println("KGV ist: " + z1);
 		
scanner.close();
    }
	{		
				

	}

}
