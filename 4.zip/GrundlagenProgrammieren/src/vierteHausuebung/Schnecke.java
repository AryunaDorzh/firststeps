package vierteHausuebung;


public class Schnecke {

	public static void main(String[] args) {
double mauer = 4.5; 
double vortschritt=0.5;
double prozent=0.9; 
int tag=0; 
double schnecke=0;

while (true) {
	tag++;
	schnecke=schnecke+vortschritt; 
	if (schnecke>mauer)
		break;
		schnecke=schnecke*prozent;
	

	}
				System.out.println("Die Schnecke ben�tigte: "+ tag + " Tage" );	
	}	
  	
}



