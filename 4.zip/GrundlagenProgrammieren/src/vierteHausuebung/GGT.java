package vierteHausuebung;

import java.util.Scanner;

public class GGT {

	public static void main(String[] args) {
		// Der euklidische Algorithmus
		// Beim euklidischen Algorithmus wird in aufeinanderfolgenden Schritten jeweils eine Division mit Rest durchgef�hrt, 
		//wobei der Rest im n�chsten Schritt zum neuen Divisor wird. Der Divisor, bei dem sich der Rest 0 ergibt,
		//ist der gr��te gemeinsame Teiler der Ausgangszahlen.
 double zahl1; 
 double zahl2; 

 Scanner scanner=new Scanner(System.in);
 System.out.println("Geben Sie die erste Zahl ein");
	zahl1 = scanner.nextDouble();
	System.out.println("Geben Sie die erste Zahl ein");
	zahl2 = scanner.nextDouble();
double ggt;
    if (zahl1 == 0) {
        ggt = zahl2;
    } else {
        while (zahl2 != 0) {
            if (zahl1 > zahl2) {
                zahl1 = zahl1 - zahl2;
            } else {
                zahl2 = zahl2 - zahl1;
            }
        }
        ggt = zahl1;
    }

  System.out.println("Gr��ter gemeinsamer Teiler ist : " + ggt);
    scanner.close();

}

}
