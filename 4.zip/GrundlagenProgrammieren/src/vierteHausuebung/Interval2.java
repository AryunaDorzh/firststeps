
package vierteHausuebung;


import java.util.Scanner;

public class Interval2 {

	public static void main(String[] args) {
		//  Intervall2: Lesen Sie zwei ganze Zahlen ein.
	 // Falls die zweite Zahl kleiner ist als die erste, geben Sie nichts aus.
	//Andernfalls geben Sie alle ganzen Zahlen von der ersten bis zur
	//zweiten aus.
	//Beispiel:
	//Eingabe: 13 und 11
//Ausgabe: nichts
//Eingabe: 7 und 11
//Ausgabe; 7, 8, 9, 10, 11
int zahl1; 
int zahl2;
Scanner scanner=new Scanner(System.in);
System.out.println("Geben Sie die erste ganze Zahl ein");
	zahl1 = scanner.nextInt();
	System.out.println("Geben Sie die zweite ganze Zahl ein");
	zahl2 = scanner.nextInt();
	scanner.close();
	if (zahl2< zahl1) {
        return;
	 } else { 
		 if (zahl2>zahl1)
			 for (int i=zahl1; i<=zahl2; i++)

	System.out.println(i);
	
	}

}
}
