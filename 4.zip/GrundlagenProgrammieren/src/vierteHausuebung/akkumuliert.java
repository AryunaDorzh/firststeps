package vierteHausuebung;

import java.util.Scanner;


public class akkumuliert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double zahl1=0;
		double summe=0;
		double grenze=0;
Scanner scanner=new Scanner(System.in);
System.out.println("Geben Sie eine Zahl ein");

	grenze = scanner.nextDouble();
	
	for (int i = 1; i <= grenze; i++)
	{
		summe += i;
		if (summe >= grenze)
		{
			zahl1 = i;
			break;
		}
	}
	System.out.println("Ihre Zahl ist: " + zahl1+", Die Summe ist : "+summe);

scanner.close();
}

	{

}
	{

}
}

