package vierteHausuebung;

import java.util.Scanner;

public class autobus {
	public static void main(String[] args) {
		while (x) {

			if (benzin == 0) {

				System.out.println("Ihr Tank ist fast leer. Wollen sie tanken oder das Spiel beenden?");
				System.out.println("1: Tanken");
				System.out.println("2: Beenden");

				String Tanken = s.nextLine();

				if (Tanken.equalsIgnoreCase("1")) {

					Tanken();

				} else if (Tanken.equalsIgnoreCase("2")) {

					Ende();

				} else {

					System.out.println("Ung�ltige Eingabe.");
				}

			} else {

				Fahren();

			}

		}

	}
	static Scanner s = new Scanner(System.in);

	static int benzin = 1;

	static boolean x = true;

	static void Tanken() {

		System.out.println("Wie viel Liter wollen  Sie tanken?(max 10 Liter)");

		int Liter = s.nextInt();

		if (Liter > 0 && Liter <= 10) {

			benzin = Liter;
			Last();
			Fahren();

		} else {

			System.out.println("Ung�ltige Eingabe.");

		}

	}

		static void Fahren() {

			System.out.println ("In welche Richtung m�chten Sie fahren? Geben Sie die passende Buchstabe ein");
			System.out.println("A: Norden ");
			System.out.println("B:S�den");
			System.out.println("C:Westen");
			System.out.println("D: Osten");
			
			System.out.println("Treibstoffstand: " + benzin);
			String Richtung = s.nextLine();

			if (Richtung.equalsIgnoreCase("A")) {

				System.out.println("Sie fahren nach Norden.");
				benzin--;

			} else if (Richtung.equalsIgnoreCase("B")) {

				System.out.println("Sie fahren nach S�den.");
				benzin--;

			} else if (Richtung.equalsIgnoreCase("C")) {

				System.out.println("Sie fahren nach Westen.");
				benzin--;

			} else if (Richtung.equalsIgnoreCase("D")) {

				System.out.println("Sie fahren nach Osten.");
				benzin--;

			} else if (Richtung.equalsIgnoreCase("Ende")) {

				Ende();

			} else {

				System.out.println("Ung�ltige Eingabe");

			}

		}
static void Ende() {

	System.out.println("Sind Sie sicher, dass Sie das Spiel beenden wollen?(Ja, Nein)");

	String Antwort = s.nextLine();

	if (Antwort.equalsIgnoreCase("Ja")) {

		System.out.println("Spiel ist beendet.");
		x = false;

	} else if (Antwort.equalsIgnoreCase("Nein")) {

	} else {

		System.out.println("Ung�ltige Eingabe.");

	}

}

static void Last() {

	String Last = s.nextLine();



{

}
}
}
