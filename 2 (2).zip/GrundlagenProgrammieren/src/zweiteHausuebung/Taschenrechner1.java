package zweiteHausuebung;

import java.util.Scanner;

public class Taschenrechner1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double zahl1 = 0;
		double zahl2 = 0;
		char operator;
		double ergebnis = 0;
		Scanner scanner = new Scanner(System.in);

		System.out.println("Geben Sie die erste Zahl ein");
		zahl1 = scanner.nextDouble();

		System.out.println("Geben Sie die zweite Zahl ein");
		zahl2 = scanner.nextDouble();
		System.out.println("Welcher Operator? Sie haben +;-;/ und * zur Auswahl");
		operator = scanner.next().charAt(0);

		switch (operator) {
		case '+':
			ergebnis = zahl1 + zahl2;
			break;

		case '-':
			ergebnis = zahl1 - zahl2;
			break;

		case '*':
			ergebnis = zahl1 * zahl2;
			break;

		case '/':
			ergebnis = zahl1 / zahl2;
			break;

		default:
			System.out.println("ung�ltiger Operator");
			scanner.close();
			return;
		}
		System.out.println(zahl1 + " " + operator + " " + zahl2 + "=" + ergebnis);
		scanner.close();

	}

}
