package zweiteHausuebung;

import java.util.Scanner;

public class Taschenrechner2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("W�hlen Sie den Operator");
		System.out.println("Addieren: 1");
		System.out.println("Subtrahieren: 2");
		System.out.println("Multiplizieren: 3");
		System.out.println("Dividieren: 4");

		Scanner scanner = new Scanner(System.in);
		int auswahl = scanner.nextInt();

		double zahl1 = 0;
		double zahl2 = 0;
		double ergebnis = 0;

		System.out.println("Geben Sie die erste Zahl ein");
		zahl1 = scanner.nextDouble();

		System.out.println("Geben Sie die zweite Zahl ein");
		zahl2 = scanner.nextDouble();
		switch (auswahl) {
		case 1:
			ergebnis = zahl1 + zahl2;
			break;

		case 2:
			ergebnis = zahl1 - zahl2;
			break;

		case 3:
			ergebnis = zahl1 * zahl2;
			break;

		case 4:
			ergebnis = zahl1 / zahl2;
			break;

		default:
			System.out.println("ung�ltiger Operator");
			return;
		}
		System.out.println("Das Ergebnis ist: " + ergebnis);
		scanner.close();

	}

}
