package zweiteHausuebung;

import java.util.Scanner;

public class primzahl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 int nummer,b,c;
 Scanner scanner1= new Scanner(System.in);
          System.out.println("Geben Sie eine Zahl ein");
          nummer =scanner1.nextInt();
          b=2;
          c=0;
           while(b<= nummer)
              {
                  if((nummer%b)==0)
                     c=c+1;
                     b++;
              }
               if(c==2)
               System.out.println(nummer +" ist eine Primzahl");
               else
               System.out.println(nummer +" ist keine Primzahl");
               scanner1.close();
	}

}
