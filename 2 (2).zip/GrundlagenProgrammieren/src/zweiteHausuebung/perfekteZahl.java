package zweiteHausuebung;

import java.util.Scanner;

public class perfekteZahl {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int zahl = 0;
		int sum = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.print("Geben Sie eine Zahl ein:");
		zahl = scanner.nextInt();
		for (int i = 1; i <= zahl; i++) {
			if (zahl % i == 0)
				;
			{
				sum = sum + i;
				if (sum == zahl) {
					System.out.println("die Zahl ist perfekt");
				} else {
					System.out.println("die Zahl ist nicht perfekt");
				}
			}
			scanner.close();
		}
	}

}
