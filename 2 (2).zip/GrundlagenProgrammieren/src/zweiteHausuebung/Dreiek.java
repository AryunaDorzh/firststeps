package zweiteHausuebung;

import java.util.Scanner;

public class Dreiek {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
// um ein Dreieck  zu formen, brauchen wir 3 Variablen, in diesem Fall von Datentyp double
		double a;
		double b;
		double c;
//Scanner um Seitenl�nge abzufragen
		Scanner scanner = new Scanner(System.in);
		System.out.print("Geben Sie erste Seitenl�nge ein:");
		a = scanner.nextDouble();
		System.out.print("Geben Sie zweite Seitenl�nge ein:");
		b = scanner.nextDouble();
		System.out.print("Geben Sie dritte Seitenl�nge ein:");
		c = scanner.nextDouble();
// if Bedingung um G�ltigkeit zu pr�fen
		if (a <= 0 || b <= 0 || c <= 0) {
			System.out.println("ung�ltige Werte");

//Ein Dreieck ist ung�ltig, wenn die Summe zweier Seitenl�ngen kleiner oder gleich der dritten Seitenl�nge ist
		} else if ((a + b < c) || (a + c < b) || (b + c < a)) {
			System.out.println(
					"Mit den L�ngenwerten " + a + ", " + b + " und " + c + " kann kein Dreieck gezeichnet werden");
		}
// 3 verschiedene Seitenl�nge
		else if (a != b && b != c && c != a)
			System.out.println("Nicht gleichseitiges Dreieck");
// alle Seiten sind gleich lang
		else if (a == b && b == c)
			System.out.println("Gleichseitiges Dreieck");
// mind zwei gleich lange Seiten
		else if ((a == b && b != c) || (a != b && c == a) || (c == b && c != a))
			System.out.println("gleichschenkliges Dreieck");
		else {
			System.out.println("Diese Konstellation ist nicht korrekt");
			scanner.close();

		}

	}

}
