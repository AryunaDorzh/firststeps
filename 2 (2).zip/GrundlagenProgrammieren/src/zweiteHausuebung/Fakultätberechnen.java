package zweiteHausuebung;

import java.util.Scanner;

public class Fakult�tberechnen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Formel f�r Berechnung n!=1*2*3...*n

		int nummer, i, fakult�t = 1;
		System.out.println("geben Sie eine Zahl ein um ihre Fakult�t zu berechnen");
		Scanner scanner1 = new Scanner(System.in);
		nummer = scanner1.nextInt();

		if (nummer < 0)
			System.out.println("Die Zahl muss positiv sein");
		else {
			for (i = 1; i <= nummer; i++)
				fakult�t = fakult�t * i;
// also with the help of Integer.MAX_VALUE
			System.out.println("Fakult�t von " + nummer + " is = " + fakult�t);

			scanner1.close();

		}

	}
}
