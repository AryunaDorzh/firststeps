package dritteHausuebung;

public class Obstkorb {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int a=1; a<=1400; a++) {
			for (int b=1; b<=1400; b++) {
				for (int g=1; g<=1400; g++) {
					if ((a+2*b+3*g==1400) && (2*a+3*b+5*g==2300) && (5*a+b+g==1000)) {
						
						System.out.println("Ein Apfel kostet:"+ a +", Banane: "+b+", Gurke:"+ g);
						}
					}
				}
			}
		}
	}
	




