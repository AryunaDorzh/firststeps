package dritteHausuebung;

public class dreimuskitiere {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int anzahl=0; 
		int plaetze=40; 
for (int athos=1; athos<=plaetze; athos++) {
	for (int portos=1; portos<=plaetze; portos++) {
		for (int aramis=1; aramis<=plaetze; aramis++) {
			if ((athos != portos) && (athos!=aramis) && (aramis !=portos)
					&& ((athos+1) !=portos) && ((portos+1) !=athos) && ((athos+1)!=aramis) && ((aramis+1) != athos) && ((portos+1)!=aramis) && ((aramis+1)!=portos) &&
					!((athos ==1) && (portos==plaetze)) && !((athos==plaetze) && (portos==1)) && 
					!((athos ==1) && (aramis==plaetze)) && !((athos==plaetze) && (aramis==1)) &&
					!((portos ==1) && (aramis==plaetze)) && !((portos==plaetze) && (aramis==1))					
					) {
				System.out.println(anzahl=anzahl+1);
			}
		}
	}
}System.out.println("Die Drei haben "+anzahl+ " M�glichkeiten sich zu platzieren");
}
	}

