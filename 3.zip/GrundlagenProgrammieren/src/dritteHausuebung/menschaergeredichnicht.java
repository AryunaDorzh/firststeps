package dritteHausuebung;

import java.util.concurrent.ThreadLocalRandom;

public class menschaergeredichnicht {
	public static void main(String[] args) {

		int p1 = 0;
		int p2 = 0;
		
		while (p1 < 50 || p2 < 50) {
			if (p1 > 0) {
				p1 = p1 + ThreadLocalRandom.current().nextInt(1, 6);
				if (p1 == p2) {
					p2 = 0;
				}
			} else {
				p1 = ThreadLocalRandom.current().nextInt(1, 6);
				if (p1 == 6) {
					p1 = 1;
				} else {
					p1 = 0;
				}
			}
			if (p2 > 0) {
				p2 = p2 + ThreadLocalRandom.current().nextInt(1, 6);
				if (p2 == p1) {
					p1 = 0;
				}
			} else {
				p2 = ThreadLocalRandom.current().nextInt(1,6);
				if (p2 == 6) {
					p2 = 1;
				} else {
					p2 = 0;
				}
			}
			p1++;
			p2++;
			
		}
		if (p1 > p2) {
			System.out.println("Spieler A gewinnt, Spieler B verliert");
		} else {
			System.out.println("Spieler B gewinnt, Spiler A verliert");
		}
	}
}
