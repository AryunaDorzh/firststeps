package dritteHausuebung;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;


public class gleichverteilung {
	
	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Wie viel Mal wird es gew�rfelt?");
	int input=scanner.nextInt();
	double eins=0; 
	double zwei=0;
	double drei=0; 
	double vier=0; 
	double fuenf=0;
	double sechs=0;
	
	double wurf1 = 0;
	double wurf2 = 0;
	double wurf3 = 0;
	double wurf4 = 0;
	double wurf5 = 0;
	double wurf6 = 0;
	int anzahl = 0;
	int min = 1;
	int max = 6;
	int i = 1;
	while (i<=input) 

	{
		i = i+1;
		int wurfe = ThreadLocalRandom.current().nextInt(min, max+1);
		anzahl = wurfe;
		if (anzahl == 1)
		{
			eins = eins + 1;
			wurf1 = (eins / input)*100;	
		}
		if (anzahl == 2)
		{
			zwei = zwei + 1;
			wurf2 =  (zwei / input)*100;
		}
		if(anzahl == 3)
		{
			drei = drei + 1;
			wurf3 =  (drei / input)*100;
		}
		if (anzahl == 4)
		{
			vier = vier + 1;
			 wurf4 =  (vier / input)*100;	
		}
		if (anzahl == 5)
		{
			fuenf = fuenf + 1;
			wurf5 =  (fuenf / input)*100;
		}
		if (anzahl == 6)
		{
			sechs= sechs + 1;
			wurf6 =  (sechs / input)*100;
			

		}			
	}
	 double round1 = Math.round(wurf1*100)/100D;
	 double round2 = Math.round(wurf2*100)/100D;
	 double round3 = Math.round(wurf3*100)/100D;
	 double round4 = Math.round(wurf4*100)/100D;
	 double round5 = Math.round(wurf5*100)/100D;
	 double round6 = Math.round(wurf6*100)/100D;

	System.out.println("\n"+"Einser wurde: "+(int)eins+" Mal gew�rfelt. Das entspricht " +round1+" % der Gesammtw�rfe");
	System.out.println("\n"+"Zweier wurde:"+(int)zwei+" Mal gew�rfelt. Das entspricht " +round2+"  % der Gesammtw�rfe");
	System.out.println("\n"+"Dreier wurde:"+(int)drei+" Mal  gew�rfelt. Das entspricht " +round3+"% der Gesammtw�rfe");
	System.out.println("\n"+"Vier wurde: "+(int)vier+" Mal gew�rfelt. Das entspricht " +round4+" % der Gesammtw�rfe");
	System.out.println("\n"+"F�nfer wurde: "+(int)fuenf+" Mal gew�rfelt. Das entspricht " +round5+"% der Gesammtw�rfe");
	System.out.println("\n"+"Sechser wurde: "+(int)sechs+" Mal gew�rfelt. Das entspricht " +round6+"% der Gesammtw�rfe");
	scanner.close();
}
	{
		
	}
	}

