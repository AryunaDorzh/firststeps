package dritteHausuebung;

public class twist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int zahl1=0;
		int zahl2=0;
		for (int z1=1; z1<=9; z1++) {
			for (int z2=0; z2<=9; z2++) {
				for (int z3=0; z3<=9; z3++) {
					for (int z4=0; z4<=9; z4++) {
						for (int z5=0; z5<=9; z5++) {
							for (int z6=0; z6<=9; z6++) {
								
								zahl1=z1*100000+z2*10000+z3*1000+z4*100+z5*10+z6;
								zahl2=z2*100000+z3*10000+z4*1000+z5*100+z6*10+z1;
								if (zahl1*3==zahl2) {
									System.out.println(zahl1);
									}
								}
							}
						}
					}
				}
			}
		}
	}

