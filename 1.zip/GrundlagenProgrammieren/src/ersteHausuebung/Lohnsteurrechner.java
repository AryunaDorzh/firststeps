package ersteHausuebung;

import java.util.Scanner;

public class Lohnsteurrechner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Bitte  geben Sie Ihr Gehalt in Euro ein");
		double gehalt = scanner.nextInt();
		 if (gehalt < 0 || gehalt >5000000) {
	            System.out.print("Gehalt kann nicht kleiner als 0 oder gr��er als 5 Millionen sein");
	        }
		 else if (gehalt <= 1066) {
			System.out.print("Sie zahlen keine Steuer. "+"Sie geh�ren in Steuerklasse 0");
		 } else if (gehalt <= 1516) {
	            double steuer1=gehalt *0.25;
	            System.out.print("Ihr Steuer ist gleich "+ steuer1+". Sie geh�ren in Steuerklasse 1");    
	     } else if (gehalt <= 2599.33) {
	    	 double steuer1=gehalt *0.35;
	         System.out.print("Ihr Steuer ist gleich "+ steuer1 +". Sie geh�ren in Steuerklasse 2");    
	        } else if (gehalt <= 5016) {
	        	double steuer2=gehalt * 0.42;
	        	 System.out.print("Ihr Steuer ist gleich "+ steuer2+". Sie geh�ren in Steuerklasse 3");
	        } else if (gehalt <= 7516) { 
	        	double steuer3=gehalt*0.48;
	        	System.out.print("Ihr Steuer ist gleich "+ steuer3+". Sie geh�ren in Steuerklasse 4");
	        } else if (gehalt <= 83349.33) { 
	        	double steuer4=gehalt*0.50;
	        	System.out.print("Ihr Steuer ist gleich "+ steuer4+". Sie geh�ren in Steuerklasse 5");
	        } else { 
	        	double steuer5=gehalt*0.55;
	        	System.out.print("Ihr Steuer ist gleich "+ steuer5+". Sie geh�ren in Steuerklasse 6");
	        			
	      scanner.close();
	        }

	}

}
