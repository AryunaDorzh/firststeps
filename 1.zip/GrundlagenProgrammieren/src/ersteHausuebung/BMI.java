package ersteHausuebung;

import java.util.Scanner;

public class BMI {

	public static void main(String[] args) {
		Scanner input=new Scanner (System.in);
		double weight;
		int height; 
		System.out.print("Geben Sie ihr Gewicht in Kilogram ein: "); 
		weight = input.nextFloat();
		 System.out.print("Geben Sie ihre Gr��e in Zentimeter ein: ");
	        height = input.nextInt();
	        double bmi = 100*100*weight /(height*height);
	        System.out.println("Ihr BMI ist: " + bmi);
	        if (bmi < 18.5 ) {
	            System.out.print("Sie sind untergewichtig");
	        }

	        else if (bmi >= 18.5 && bmi < 25) {
	            System.out.print("Ihr BMI ist optinal");
	        }

	        else if (bmi >= 25 && bmi < 30) {
	            System.out.print("Sie sind �bergewichtig");
	        }

	     input.close();
	}

}
