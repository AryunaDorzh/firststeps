package ersteHausuebung;

public class Zuweisung {

	public static void main(String[] args) {
		
		
//		�berlege dir, was f�r eine Ausgabe der folgende Code erzeugen w�rde.
//		Compiliere den Code, f�hre ihn aus und vergleiche das Resultat mit deinen Erwartungen.
//		Was sind die Unterschiede?
// Die Ausgabe ist wie erwartet 0,0,0,1. 
				System.out.println(0);
				
				int zero = 0;
				
				System.out.println(zero);
				
				int one = 1;
				
				int whatsThis = zero;
				
				System.out.println(whatsThis);
				
				whatsThis = one;
				
				System.out.println(whatsThis);
			
		}
	}

