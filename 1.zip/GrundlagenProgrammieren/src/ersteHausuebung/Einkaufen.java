package ersteHausuebung;

import java.util.Scanner;

public class Einkaufen {
	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Geben Sie den Namen des Produktes ein: ");
	String produkt1 = scanner.next();
	System.out.println("Geben Sie die Anzahl des Produktes: ");
	int anzahl1 = scanner.nextInt();
	System.out.println("Geben Sie den Preis des Produktes: ");
	double preis1 = scanner.nextFloat();
	double ZwischenE1 = Math.round(anzahl1*preis1*100.0)/100.0;
	System.out.println(ZwischenE1);		
	System.out.println("Geben Sie das zweite Produkt ein: ");
	String produkt2 = scanner.next();
	System.out.println("Geben Sie die Anzahl des Produktes: ");
	int anzahl2 = scanner.nextInt();
	System.out.println("Geben Sie den Preis des Produktes: ");
	double preis2 = scanner.nextFloat();
	double ZwischenE2 = Math.round(anzahl2*preis2*100.0)/100.0;
	System.out.println(ZwischenE2);	
double gesamt=(anzahl1*preis1)+(anzahl2*preis2); 
System.out.println("Ihr Zahlbetrag  von"+ produkt1+ produkt2 + "ist"+ gesamt);
System.out.println("Geben Sie ihren Betrag ein: ");
double gegeben = scanner.nextFloat();
double zurueck=(gegeben-gesamt);
System.out.println("Ihr Wechselgeld: " + zurueck);
	scanner.close();
				
	}

	}
		
// dieses BSP ist lediglich nice-to-have
		
		// Sie gehen Einkaufen, und werden an der Kassa gefragt, wieviel St�ck Sie von einem Produkt gekauft haben
		// und den jeweiligen Preis des Artikels, nachdem alle Artikel eintragen wurden(die Anzahl ist beliebig, 2 gen�gen)
		// Werden Sie abschlie�end �ber den Zahlbetrag informiert und "�bergeben" das Geld, darauf wird Ihnen das 
		// Retourgeld angezeigt.
		// Eine L�sung k�nnte so aussehen
		
//Wurst      1 x  4.20 EUR
//        4.20 EUR
//K�se       1 x  2.30 EUR
//        2.30 EUR
//Brot       1 x  2.10 EUR
//        2.10 EUR
//DVD        2 x 12.00 EUR
//       24.00 EUR
//----------------------------------
//Gesamt                   32.60 EUR
//Gegeben                  50.00 EUR
//
//Zur�ck                   17.40 EUR

	