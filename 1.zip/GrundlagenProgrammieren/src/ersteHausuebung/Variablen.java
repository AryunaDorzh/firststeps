package ersteHausuebung;

public class Variablen {

	public static void main(String[] args) {
		// deklariere eine Variable "birnen"  vom Typ int

		int birnen=3;
		// weise ihr den Wert drei zu

		System.out.println("3 erwartet: " + birnen);
	

		// addiere fuenf zu dem Wert
		birnen = birnen+5;	

		
		System.out.println("8 erwartet: " + birnen);
		// deklariere eine Variable "aepfel" und weise ihr den Wert fuenf zu
		int aepfel=5;
		
		System.out.println("5 erwartet: " + aepfel);
		// subtrahiere zwei von dem Wert
		aepfel=aepfel-2;

		System.out.println("3 erwartet: " + aepfel);

	}

}
