package ersteHausuebung;

public class Casten {

	public static void main(String[] args) {


		// Die nachfolgende Kommazahl stellt den Rechnungsbetrag dar,
		// geben Sie diesen per Konsole aus. jedoch muss dieser vom Typ int sein
		// dennoch m�ssen die Nachkommastellen  ersichtlich sein, 2 Stellen gen�gen
		
		
		double kommazahl = 123.9564998455;
		System.out.println(kommazahl);
		int integer= (int) kommazahl; 
		System.out.println(integer);
		System.out.format("double : %.2f", kommazahl);
		 
		
	

	}

}
