package fuenfteHausuebung;
import java.util.Scanner;

public class rechteck {

	public static void main(String[] args) {

	Scanner scanner = new Scanner(System.in);
	System.out.print("Geben Sie die Breite des Rechtsecks ein:");
	double a = scanner.nextDouble();
	System.out.print("Geben Sie die L�nge des Rechtsecks ein:");
	double b = scanner.nextDouble();
	scanner.close(); 
Umfang(a, b);
	}
	 static void Umfang(double a, double b){
		double ergebnis=2*a+2*b;
		 System.out.println("Der Umgang des Rechtecks betr�gt "+ ergebnis);
		 }
	 {
	}
	
}
