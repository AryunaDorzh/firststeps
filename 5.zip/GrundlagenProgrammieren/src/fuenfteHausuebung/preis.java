package fuenfteHausuebung;

import java.util.Scanner;


public class preis {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.print("Geben Sie den Preis des Produktes ein: ");
		double preis = scanner.nextDouble();
		System.out.print("Geben Sie die Anzahl des Produkts ein: ");
		int anzahl = scanner.nextInt();
		System.out.print("Geben Sie den Mehrwertsteuersatz ein: ");
		double mwst = scanner.nextDouble();
		scanner.close(); 
		Gesamtpreis(preis, anzahl, mwst);
	}
		static void Gesamtpreis (double preis, double anzahl, double mwst){
			double gesamtpreis=(preis*anzahl)*(mwst/100)+preis*anzahl; 
			 System.out.println("Der Gesamtpreis ist  "+ gesamtpreis);
			 }
		 {
		}
		
		 {

	}

}
