package fuenfteHausuebung;

import java.util.Scanner;

public class chemie {

	public static void main(String[] args) {
		// H2 + 0.5 O2 => H2O
		//relation 1:8 H2 zu O=>  h2*8
		//wasser => h2*9
Scanner scanner = new Scanner(System.in);
System.out.print("Wie viel Gram Wasserstoff wollen Sie verbrennen?");
double wasserstoff = scanner.nextDouble();
scanner.close(); 
double sauer = 0;
Wasser(wasserstoff, sauer);

	}
static void Wasser (double wasserstoff, double sauerstoff){
sauerstoff=wasserstoff*8;
double wasser=wasserstoff*9;
 System.out.println("Sie brauchen " + sauerstoff + " Gram Sauerstoff. Es entstehen "+ wasser + " Gram Wasser");
		
		}
		
	}
