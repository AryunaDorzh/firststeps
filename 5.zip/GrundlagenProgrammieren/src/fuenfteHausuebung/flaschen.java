package fuenfteHausuebung;

import java.util.Scanner;

public class flaschen {

	public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
System.out.print("Geben Sie das Fassungsverm�gen der Flasche ein:");
double kapazit�t = scanner.nextDouble();
System.out.print("Geben Sie die Anzahl der Flaschen ein:");
double anzahl= scanner.nextDouble();
scanner.close(); 
Gesamtkapaziz�t(kapazit�t, anzahl);
	}
	
static void Gesamtkapaziz�t (double kapazit�t, double anzahl){
	double gesamtkapazit�t=kapazit�t*anzahl;
	 System.out.println("Das Gesamtfassungsverm�gen ist  "+ gesamtkapazit�t);
}
}