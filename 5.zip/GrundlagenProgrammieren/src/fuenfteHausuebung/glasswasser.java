package fuenfteHausuebung;

import java.util.Scanner;

public class glasswasser {
public static Scanner s = new Scanner(System.in);
	public static void main(String[] args) {
		
		boolean spiel = true;
		double schluck;
		System.out.println("Haben Sie Durst? 1: Ja, 2: Nein");
			String Antwort = s.nextLine();
			if (Antwort.equalsIgnoreCase("1")) {
			System.out.println("Bitte w�hlen Sie die Aktivit�t ein");
			
		do {
			System.out.println("Jetzt was?");
			System.out.println("1: Trinken");
			System.out.println("2:Nachf�hlen");
			System.out.println("3:aktueller Stand");
			System.out.println("4: Ende");
			int option = s.nextInt();
			switch (option) {
			case 1:
				System.out.println("Wie viel wollen Sie trinken, max 250 ml?");
				schluck = s.nextDouble();
				trinken (schluck);
				System.out.println("Sehr gut! Sie haben " +schluck + " ml Wasser getrunken");
				Volumen();
				break;
			case 2:
				if (inhalt < max) {
					tanken();
					
				}else {
					System.out.println("Ihr Glas ist noch voll");
				}
				break;
			case 3:
				stand();
				break;
			case 4:
				System.out.println("Klar, bis  zum n�chsten Mal");
				spiel = false;
				break;
			default:
				System.out.println("Ung�ltige Eingabe.");
				break;
			} 
	} while (spiel);
	}
			else {
				System.out.println("Klar, bis zum n�chsten Mal!");
			}
	}
	
	
	private static double inhalt = 250;
	private static final int max = 250;

	private static void trinken (double stand) {
		if (stand <= inhalt && stand > 0) {
			inhalt -= stand;
		} else {
			System.out.println("Ung�ltige Eingabe");
		}
	}

	private static void tanken() {
		boolean meldung = false;
		do {
			System.out.println("Wie viel wollen Sie nachf�llen?");
			double auff�llen = s.nextDouble();
			System.out.println("wollen Sie: Wasser oder Bier (Ottakringer) nachf�llen?");
			String fl�ssigkeit = s.next().toLowerCase();
			if (fl�ssigkeit.equalsIgnoreCase("Wasser")) {
				if ((auff�llen + inhalt) <= max && auff�llen > 0) {
					inhalt = auff�llen + inhalt;
					System.out.println("Sie haben jetzt " + inhalt + " im Glas");
					Volumen();
					break;
				} else {
					meldung = true;
					System.out.println("ung�ltige Eingabe. \nSie k�nnen max. " + (max - inhalt) + "ml nachf�llen");	
				}
			} else if (fl�ssigkeit.equalsIgnoreCase("bier"))  {
				meldung=true;
			System.out.println("das Verfahren kann nicht durchgef�hrt werden. Alkoholkonsum ist schlecht f�r ihre Gesundheit");

				}
		} while (meldung);
	}
	private static void stand() {
		System.out.println("Sie haben " + inhalt + "ml Wasser im Glas.");
		Volumen();
	}
	
	private static void Volumen() {
		double r = 2.821;
		double h = 10;
		double V = (Math.PI*Math.pow(r, 2)* h);
	
		double aktuell = V - ( V - inhalt );
		System.out.printf("Das aktuelle Volumen betr�gt  %9.2f.\n", aktuell);	
	}

{

	}

}
