package fuenfteHausuebung;

import java.util.Scanner;

public class schrottersaecke {

	public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
System.out.print("Geben Sie das Gewicht des leeren LKWs ein:");
		double leer = scanner.nextDouble();
		System.out.print("Geben Sie das Gewicht des beladenen LKWs ein:");
		double voll= scanner.nextDouble();
		scanner.close(); 
		Saecke(voll, leer);
	}
	static void Saecke (double voll, double leer){
		if (leer >100 && voll>150) {
		double saecke=(voll-leer)/50;
		 System.out.println("Sie haben "+ Math.floor(saecke) + " S�cke geladen");
		 //habe gerundet, da wir davon ausgehen, die S�cke sind voll geladen
		}
		 else {
				System.out.println("inkorrekte Eingabe");
}
	}
}